module com.example.dresscollection {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.dresscollection to javafx.fxml;
    exports com.example.dresscollection;
}